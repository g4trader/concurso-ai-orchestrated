"""
Utilities module

Módulo responsável por utilitários e funções auxiliares.
"""
