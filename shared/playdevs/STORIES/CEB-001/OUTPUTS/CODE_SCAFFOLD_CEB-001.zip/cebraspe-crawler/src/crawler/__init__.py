"""
Crawler module

Módulo responsável pela lógica de crawling e descoberta de documentos.
"""
