"""
Cebraspe Crawler Package

Sistema para descoberta, download e catalogação de documentos públicos da banca Cebraspe.
"""

__version__ = "1.0.0"
__author__ = "Cebraspe Crawler Team"
