"""
Configuration settings for Cebraspe Crawler

Este módulo define todas as configurações do sistema.
Responsabilidades:
- Carregamento de variáveis de ambiente
- Validação de configurações
- Valores padrão
- Configurações específicas por ambiente
"""

import os
from dataclasses import dataclass
from typing import Optional
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

@dataclass
class CrawlerConfig:
    """Configurações principais do crawler"""
    
    # URLs e domínios
    base_url: str = "https://www.cebraspe.org.br"
    user_agent: str = "CebraspeCrawler/1.0"
    
    # Configurações de download
    max_concurrent_downloads: int = 5
    request_timeout: int = 30
    retry_attempts: int = 3
    rate_limit_delay: float = 1.0
    
    # Diretórios
    output_dir: str = "./data"
    pdfs_dir: str = "./data/pdfs"
    logs_dir: str = "./logs"
    
    # Logging
    log_level: str = "INFO"
    log_format: str = "json"
    
    # Modo de operação
    debug: bool = False
    dry_run: bool = False
    
    @classmethod
    def load(cls) -> "CrawlerConfig":
        """
        Carrega configurações das variáveis de ambiente
        
        Returns:
            CrawlerConfig: Instância configurada
        """
        return cls(
            base_url=os.getenv("CEBRASPE_BASE_URL", cls.base_url),
            user_agent=os.getenv("USER_AGENT", cls.user_agent),
            max_concurrent_downloads=int(os.getenv("MAX_CONCURRENT_DOWNLOADS", cls.max_concurrent_downloads)),
            request_timeout=int(os.getenv("REQUEST_TIMEOUT", cls.request_timeout)),
            retry_attempts=int(os.getenv("RETRY_ATTEMPTS", cls.retry_attempts)),
            rate_limit_delay=float(os.getenv("RATE_LIMIT_DELAY", cls.rate_limit_delay)),
            output_dir=os.getenv("OUTPUT_DIR", cls.output_dir),
            pdfs_dir=os.getenv("PDFS_DIR", cls.pdfs_dir),
            logs_dir=os.getenv("LOGS_DIR", cls.logs_dir),
            log_level=os.getenv("LOG_LEVEL", cls.log_level),
            log_format=os.getenv("LOG_FORMAT", cls.log_format),
            debug=os.getenv("DEBUG", "false").lower() == "true",
            dry_run=os.getenv("DRY_RUN", "false").lower() == "true",
        )
    
    def validate(self) -> None:
        """
        Valida configurações carregadas
        
        Raises:
            ValueError: Se configurações são inválidas
        """
        if self.max_concurrent_downloads <= 0:
            raise ValueError("max_concurrent_downloads deve ser > 0")
        
        if self.request_timeout <= 0:
            raise ValueError("request_timeout deve ser > 0")
        
        if self.retry_attempts < 0:
            raise ValueError("retry_attempts deve ser >= 0")
        
        # Criar diretórios se não existirem
        for directory in [self.output_dir, self.pdfs_dir, self.logs_dir]:
            os.makedirs(directory, exist_ok=True)
