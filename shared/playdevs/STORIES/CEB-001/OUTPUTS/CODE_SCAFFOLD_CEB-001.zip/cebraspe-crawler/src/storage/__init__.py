"""
Storage module

Módulo responsável pelo armazenamento e indexação de dados.
"""
