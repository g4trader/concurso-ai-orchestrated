"""
Test package for Cebraspe Crawler

Pacote de testes para o sistema de crawling da Cebraspe.
"""
