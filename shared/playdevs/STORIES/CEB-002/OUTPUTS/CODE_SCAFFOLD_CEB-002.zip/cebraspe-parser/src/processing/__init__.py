"""
Processing module

Módulo responsável pelo processamento e normalização de texto extraído.
"""
