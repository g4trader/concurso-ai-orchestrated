"""
Data models module

Módulo responsável por definir os modelos de dados do sistema de parsing.
"""
