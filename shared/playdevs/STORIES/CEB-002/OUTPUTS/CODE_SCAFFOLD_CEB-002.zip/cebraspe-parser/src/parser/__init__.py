"""
Parser module

Módulo responsável pela lógica de parsing e extração de texto de documentos PDF.
"""
