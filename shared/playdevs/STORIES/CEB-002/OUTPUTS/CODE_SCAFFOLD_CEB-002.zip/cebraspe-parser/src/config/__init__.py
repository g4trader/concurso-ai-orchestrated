"""
Configuration module

Módulo responsável por gerenciar configurações do sistema de parsing.
"""
