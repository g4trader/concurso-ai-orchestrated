"""
Cebraspe Parser Package

Sistema para extração de texto e metadados de documentos PDF da banca Cebraspe,
com suporte a OCR para PDFs baseados em imagem.
"""

__version__ = "1.0.0"
__author__ = "Cebraspe Parser Team"
