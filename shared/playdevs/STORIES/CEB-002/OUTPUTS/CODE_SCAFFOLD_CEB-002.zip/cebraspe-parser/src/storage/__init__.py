"""
Storage module

Módulo responsável pelo armazenamento e gerenciamento de arquivos.
"""
