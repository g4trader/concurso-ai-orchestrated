"""
Test package for Cebraspe Parser

Pacote de testes para o sistema de parsing de documentos PDF.
"""
